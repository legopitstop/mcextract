__version__ = '1.0.0'

from .server import Server, Status, StatusEvent
from .client import CTkClient
